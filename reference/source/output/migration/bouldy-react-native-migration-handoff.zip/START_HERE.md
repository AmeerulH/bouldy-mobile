# Start here

This is the Bouldy 1:1 React Native migration planning handoff, prepared 28 October 2026.

1. Read docs/REACT_NATIVE_MIGRATION_SPEC.md.
2. Read docs/migration/IMPLEMENTATION_HANDOFF.md and PARITY_REGISTER.md.
3. Use NOTION_LINKS.json to open the live plan/spec/register/handoff.
4. The current app source remains in the old repo; this archive is not a full source/Git backup.

All migration items are unstarted. The original screenshots are sample data captured 24 October, not newly verified production or native goldens. Follow M0 before implementing; preserve the exact UI and flow.

PACKAGE_MANIFEST.json hashes each included reference file. No credentials or native project are included.
